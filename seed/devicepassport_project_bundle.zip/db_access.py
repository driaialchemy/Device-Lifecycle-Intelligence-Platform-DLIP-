from __future__ import annotations

import os
import json
from typing import Any, Dict, List, Optional

import pandas as pd
import psycopg2
from psycopg2.extras import RealDictCursor, Json


def _db_url() -> str:
    url = os.getenv("DP_DATABASE_URL", "").strip()
    if not url:
        raise RuntimeError("DP_DATABASE_URL is not set.")
    return url


def connect():
    return psycopg2.connect(_db_url())


def init_db_schema() -> None:
    ddl = '''
    CREATE TABLE IF NOT EXISTS devices (
      device_id TEXT PRIMARY KEY,
      device_payload JSONB NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS runs (
      run_id TEXT PRIMARY KEY,
      device_id TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS agent_outputs (
      id BIGSERIAL PRIMARY KEY,
      run_id TEXT NOT NULL,
      device_id TEXT NOT NULL,
      agent_name TEXT NOT NULL,
      domain TEXT NOT NULL,
      round INT NOT NULL,
      stance TEXT,
      text TEXT NOT NULL,
      risk_rating TEXT,
      uncertainty DOUBLE PRECISION,
      tool_outputs JSONB,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS tool_events (
      id BIGSERIAL PRIMARY KEY,
      run_id TEXT NOT NULL,
      device_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      tool_name TEXT NOT NULL,
      tool_version TEXT,
      artifact_hash TEXT,
      input_data_ref TEXT,
      metrics_json JSONB,
      warnings_json JSONB,
      confidence DOUBLE PRECISION,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS audit_chain (
      id BIGSERIAL PRIMARY KEY,
      run_id TEXT NOT NULL,
      device_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      payload_json JSONB NOT NULL,
      prev_hash TEXT,
      event_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS sensor_timeseries (
      id BIGSERIAL PRIMARY KEY,
      device_id TEXT NOT NULL,
      ts TIMESTAMPTZ NOT NULL,
      sensor TEXT NOT NULL,
      value DOUBLE PRECISION NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sensor_device_sensor_ts ON sensor_timeseries(device_id, sensor, ts);

    CREATE TABLE IF NOT EXISTS battery_history (
      id BIGSERIAL PRIMARY KEY,
      device_id TEXT NOT NULL,
      dt DATE NOT NULL,
      battery_health_pct DOUBLE PRECISION NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_battery_device_dt ON battery_history(device_id, dt);
    '''
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute(ddl)
        conn.commit()


def count_devices() -> int:
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM devices;")
            return int(cur.fetchone()[0])


def list_devices(limit: int = 1000) -> List[Dict[str, Any]]:
    sql = "SELECT device_id, device_payload FROM devices ORDER BY device_id LIMIT %s;"
    with connect() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, (limit,))
            return list(cur.fetchall())


def get_device_payload(device_id: str) -> Dict[str, Any]:
    sql = "SELECT device_payload FROM devices WHERE device_id=%s;"
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (device_id,))
            row = cur.fetchone()
            if not row:
                raise KeyError(f"device_id not found: {device_id}")
            payload = row[0]
            if isinstance(payload, str):
                return json.loads(payload)
            return payload


def bulk_upsert_devices_from_dataframe(df: pd.DataFrame) -> int:
    upserted = 0
    with connect() as conn:
        with conn.cursor() as cur:
            for _, r in df.iterrows():
                did = str(r.get("device_id", "")).strip()
                if not did:
                    continue
                payload: Dict[str, Any] = {}
                for k, v in r.to_dict().items():
                    if pd.isna(v):
                        payload[k] = None
                    elif hasattr(v, "isoformat"):
                        payload[k] = v.isoformat()
                    else:
                        payload[k] = v

                for key in ["r2v3_flags_json", "gdpr_flags_json"]:
                    raw = payload.get(key)
                    if isinstance(raw, str) and raw.strip().startswith("{"):
                        try:
                            payload[key.replace("_json", "")] = json.loads(raw)
                        except Exception:
                            pass

                cur.execute(
                    '''
                    INSERT INTO devices (device_id, device_payload)
                    VALUES (%s,%s)
                    ON CONFLICT (device_id) DO UPDATE
                    SET device_payload = EXCLUDED.device_payload,
                        updated_at = NOW();
                    ''',
                    (did, Json(payload)),
                )
                upserted += 1
        conn.commit()
    return upserted


def replace_sensor_timeseries(df: pd.DataFrame) -> int:
    req = {"device_id", "timestamp", "sensor", "value"}
    if not req.issubset(set(df.columns)):
        raise ValueError(f"sensor_timeseries missing columns: {sorted(req - set(df.columns))}")
    n = 0
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute("TRUNCATE TABLE sensor_timeseries;")
            for _, r in df.iterrows():
                cur.execute(
                    "INSERT INTO sensor_timeseries (device_id, ts, sensor, value) VALUES (%s,%s,%s,%s);",
                    (str(r["device_id"]), r["timestamp"], str(r["sensor"]), float(r["value"])),
                )
                n += 1
        conn.commit()
    return n


def replace_battery_history(df: pd.DataFrame) -> int:
    req = {"device_id", "date", "battery_health_pct"}
    if not req.issubset(set(df.columns)):
        raise ValueError(f"battery_history missing columns: {sorted(req - set(df.columns))}")
    n = 0
    with connect() as conn:
        with conn.cursor() as cur:
            cur.execute("TRUNCATE TABLE battery_history;")
            for _, r in df.iterrows():
                cur.execute(
                    "INSERT INTO battery_history (device_id, dt, battery_health_pct) VALUES (%s,%s,%s);",
                    (str(r["device_id"]), r["date"], float(r["battery_health_pct"])),
                )
                n += 1
        conn.commit()
    return n


def fetch_sensor_series(device_id: str, sensor: str) -> pd.DataFrame:
    sql = "SELECT ts, value FROM sensor_timeseries WHERE device_id=%s AND sensor=%s ORDER BY ts ASC;"
    with connect() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, (device_id, sensor))
            rows = cur.fetchall()
    df = pd.DataFrame(rows)
    if not df.empty:
        df["ts"] = pd.to_datetime(df["ts"], utc=True)
        df["value"] = df["value"].astype(float)
    return df


def fetch_battery_history(device_id: str) -> pd.DataFrame:
    sql = "SELECT dt, battery_health_pct FROM battery_history WHERE device_id=%s ORDER BY dt ASC;"
    with connect() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, (device_id,))
            rows = cur.fetchall()
    df = pd.DataFrame(rows)
    if not df.empty:
        df["dt"] = pd.to_datetime(df["dt"])
        df["battery_health_pct"] = df["battery_health_pct"].astype(float)
    return df


def fetch_audit_chain(run_id: str) -> pd.DataFrame:
    sql = "SELECT id, created_at, event_type, prev_hash, event_hash, payload_json FROM audit_chain WHERE run_id=%s ORDER BY id ASC;"
    with connect() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql, (run_id,))
            rows = cur.fetchall()
    return pd.DataFrame(rows)
