from __future__ import annotations

import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt

from orchestrator import Orchestrator
from llm_client import LLMClient, verify_llm_provider_available

from db_access import init_db_schema, list_devices, get_device_payload, fetch_sensor_series, fetch_battery_history, fetch_audit_chain
from db_persist import persist_tool_event
from tools import fft_welch_from_db
from forecasting import forecast_with_uncertainty


def _llm_optional(provider: str):
    try:
        verify_llm_provider_available(provider)
        return LLMClient(provider=provider)
    except Exception:
        return None


def interpret_fft(device: dict, metrics: dict) -> str:
    prompt = f"""You are an expert wearable sensor analyst.
DEVICE: {device.get('device_id')} {device.get('brand')} {device.get('model')}
FFT METRICS: {metrics}
Write sections exactly:
INTERPRETATION:
QUALITY FLAGS:
REFURB RECOMMENDATION:
FACT CHECK:
REFLECTION:
COGNITIVE VERIFICATION:
Constraints: no JSON output; do not invent data."""
    client = _llm_optional("openai")
    if client:
        return client.complete(prompt, max_tokens=700)

    dom = float(metrics.get("dominant_freq_hz", 0.0) or 0.0)
    bp_lo = float(metrics.get("bandpower_0_3hz", 0.0) or 0.0)
    bp_hi = float(metrics.get("bandpower_3_10hz", 0.0) or 0.0)
    nf = float(metrics.get("noise_floor", 0.0) or 0.0)
    ratio = bp_hi / max(bp_lo, 1e-9)
    rec = "Pass" if ratio < 0.25 and nf < 0.01 else "Needs Review"

    return f"""INTERPRETATION:
Dominant frequency ~{dom:.3f} Hz with low-frequency concentration suggests periodic content in the window.

QUALITY FLAGS:
Noise floor={nf:.6f}; high/low bandpower ratio={ratio:.3f}.

REFURB RECOMMENDATION:
{rec}.

FACT CHECK:
Limited to PSD summary metrics provided.

REFLECTION:
Stationary segments or irregular sampling can bias PSD.

COGNITIVE VERIFICATION:
1) Repeat FFT on another window. 2) Cross-check gyro vs accel. 3) Time-domain spike/outlier scan."""


def interpret_forecast(device: dict, forecast: dict) -> str:
    prompt = f"""You are a refurbishment analytics reviewer.
DEVICE: {device.get('device_id')} {device.get('brand')} {device.get('model')}
FORECAST: {forecast}
Write sections:
INTERPRETATION:
RISK FLAGS:
DECISION:
FACT CHECK:
NEXT CHECKS:
Constraints: no JSON output; be conservative."""
    client = _llm_optional("openai")
    if client:
        return client.complete(prompt, max_tokens=650)

    slope = float(forecast.get("linear", {}).get("slope", 0.0))
    decision = "Pass" if slope > -0.12 else "Needs Review"

    return f"""INTERPRETATION:
Linear slope is {slope:.4f} pct/day; ensemble blends linear + spectral 'neural-operator-like' model.

RISK FLAGS:
Steep negative slope or rising uncertainty implies accelerated degradation.

DECISION:
{decision}.

FACT CHECK:
Based only on battery_history.

NEXT CHECKS:
Validate last 7 days, compare cohort, confirm cycle count if available."""


st.set_page_config(page_title="Device Passport — DB-first", layout="wide")
st.title("Device Passport — DB-first")
st.caption("All analytics use Postgres data: devices, sensor_timeseries, battery_history. No uploads. Charts + agentic interpretation. Hash-chained audit trail.")

init_db_schema()

devices = list_devices(limit=1000)
if not devices:
    st.error("No devices in DB. Seeding should have run automatically on container start.")
    st.stop()

labels, ids = [], []
for row in devices:
    did = row.get("device_id")
    payload = row.get("device_payload") or {}
    labels.append(f"{did} | {payload.get('brand','')} {payload.get('model','')} | {payload.get('serial_number','')}")
    ids.append(did)

sel = st.selectbox("Select device", labels, index=0)
device_id = ids[labels.index(sel)]
device = get_device_payload(device_id)

tabs = st.tabs(["Device", "Audit (Agents+Arbiter)", "FFT / Spectral", "Forecasting", "Audit Trail (Hash Chain)"])

with tabs[0]:
    st.subheader("Device Record")
    st.dataframe(pd.DataFrame([device]), use_container_width=True, hide_index=True)

with tabs[1]:
    st.subheader("Audit (Multi-agent + verifier + arbiter + meta)")
    if st.button("Run Audit", type="primary"):
        with st.spinner("Running audit..."):
            orch = Orchestrator()
            res = orch.run_device_audit(device)
        st.session_state["last_run_id"] = res.get("run_id")
        st.success(f"Audit completed. run_id={res.get('run_id')}")
        st.markdown("### Final Narrative")
        st.markdown(res.get("final_narrative",""))
        st.markdown("### Final Uncertainty")
        st.write(res.get("final_uncertainty"))

with tabs[2]:
    st.subheader("FFT / Spectral (from sensor_timeseries)")
    sensor = st.selectbox("Sensor", ["accelerometer_mag", "gyroscope_mag", "ppg_signal"], index=0)
    window_seconds = st.slider("Window length (seconds)", 5, 60, 30, 5)

    df = fetch_sensor_series(device_id, sensor)
    if df.empty:
        st.warning("No sensor series for this device.")
    else:
        end_ts = df["ts"].iloc[-1]
        start_ts = end_ts - pd.Timedelta(seconds=int(window_seconds))
        dfw = df[df["ts"] >= start_ts].copy()

        st.markdown("### Time-domain preview")
        st.line_chart(dfw.set_index("ts")["value"])

        if st.button("Run FFT and Interpret"):
            freqs, psd, metrics = fft_welch_from_db(device_id, sensor=sensor, start_ts=start_ts.isoformat(), end_ts=end_ts.isoformat(), nperseg=256)

            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(freqs, psd)
            ax.set_title(f"Welch PSD — {sensor}")
            ax.set_xlabel("Frequency (Hz)")
            ax.set_ylabel("Power")
            ax.grid(True, alpha=0.25)
            st.pyplot(fig, clear_figure=True)

            bp = {"0–3 Hz": float(metrics["bandpower_0_3hz"]), "3–10 Hz": float(metrics["bandpower_3_10hz"])}
            st.bar_chart(pd.DataFrame({"bandpower": bp}))

            st.dataframe(pd.DataFrame([
                {"metric":"dominant_freq_hz","value":round(float(metrics["dominant_freq_hz"]),6)},
                {"metric":"bandpower_0_3hz","value":round(float(metrics["bandpower_0_3hz"]),6)},
                {"metric":"bandpower_3_10hz","value":round(float(metrics["bandpower_3_10hz"]),6)},
                {"metric":"noise_floor","value":round(float(metrics["noise_floor"]),8)},
                {"metric":"sample_rate_hz_est","value":round(float(metrics["sample_rate_hz_est"]),4)},
            ]), use_container_width=True, hide_index=True)

            run_id = st.session_state.get("last_run_id") or "run_fft_only"
            persist_tool_event(
                run_id=run_id,
                device_id=device_id,
                event_type="fft",
                tool_name="fft_welch",
                tool_version="1.0",
                input_data_ref=f"sensor_timeseries({sensor})[{start_ts.isoformat()}..{end_ts.isoformat()}]",
                metrics_json=metrics,
                warnings_json={},
                confidence=0.9,
            )
            st.success("Logged FFT tool_event.")
            st.subheader("Agentic interpretation")
            st.markdown(interpret_fft(device, metrics))

with tabs[3]:
    st.subheader("Forecasting (battery_history)")
    horizon = st.slider("Forecast horizon (days)", 7, 90, 30, 7)
    bh = fetch_battery_history(device_id)
    if bh.empty:
        st.warning("No battery history for this device.")
    else:
        st.line_chart(bh.set_index("dt")["battery_health_pct"])
        if st.button("Run Forecast and Interpret"):
            hist = bh["battery_health_pct"].to_numpy(dtype=float)
            fc = forecast_with_uncertainty(hist, int(horizon))
            last = bh["dt"].iloc[-1]
            fut = pd.date_range(last + pd.Timedelta(days=1), periods=int(horizon), freq="D")

            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(bh["dt"], hist, label="history")
            ax.plot(fut, np.asarray(fc["ensemble"]["forecast"]), label="forecast")
            ax.set_title("Battery Health Forecast (Ensemble)")
            ax.set_xlabel("Date")
            ax.set_ylabel("Battery health (%)")
            ax.grid(True, alpha=0.25)
            ax.legend()
            st.pyplot(fig, clear_figure=True)

            st.dataframe(pd.DataFrame([
                {"metric":"linear_slope_pct_per_day","value":round(float(fc["linear"]["slope"]),6)},
                {"metric":"linear_sigma","value":round(float(fc["linear"]["sigma"]),6)},
                {"metric":"neural_operator_like_modes","value":fc["neural_operator_like"].get("modes")},
            ]), use_container_width=True, hide_index=True)

            run_id = st.session_state.get("last_run_id") or "run_forecast_only"
            persist_tool_event(
                run_id=run_id,
                device_id=device_id,
                event_type="forecast",
                tool_name="battery_forecast_ensemble",
                tool_version="1.0",
                input_data_ref="battery_history(dt,battery_health_pct)",
                metrics_json={"horizon_days": int(horizon), **fc},
                warnings_json={},
                confidence=0.85,
            )
            st.success("Logged forecast tool_event.")
            st.subheader("Agentic interpretation")
            st.markdown(interpret_forecast(device, {"horizon_days": int(horizon), **fc}))

with tabs[4]:
    st.subheader("Audit Trail (hash chain)")
    run_id = st.session_state.get("last_run_id")
    if not run_id:
        st.info("Run an audit first to generate a run_id and audit chain.")
    else:
        chain = fetch_audit_chain(run_id)
        if chain.empty:
            st.warning("No audit chain records for this run.")
        else:
            st.dataframe(chain[["id","created_at","event_type","prev_hash","event_hash"]], use_container_width=True, hide_index=True)
