from typing import Any, Dict

class MetaReviewer:
    def review(self, provisional_decision: Dict[str, Any], device_dict: Dict[str, Any], cove_report: Dict[str, Any]) -> Dict[str, Any]:
        unc=0.35
        if (cove_report or {}).get('missing_device_fields'):
            unc+=0.15
        if (cove_report or {}).get('tool_errors'):
            unc+=0.20
        unc=min(0.95,unc)
        narrative=(f"Provisional risk rating: {provisional_decision.get('arbiter_risk_rating')}.\n" +
                  f"Verifier issues: {provisional_decision.get('verifier_issues') or []}.\n" +
                  "This narrative is conservative and evidence-bounded.")
        return {'adjusted_narrative':narrative,'final_uncertainty':unc}
